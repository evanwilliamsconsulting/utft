/*
  UTFT.cpp - Arduino/chipKit library support for Color TFT LCD Boards
  Copyright (C)2010-2013 Henning Karlsen. All right reserved
  
  This library is the continuation of my ITDB02_Graph, ITDB02_Graph16
  and RGB_GLCD libraries for Arduino and chipKit. As the number of 
  supported display modules and controllers started to increase I felt 
  it was time to make a single, universal library as it will be much 
  easier to maintain in the future.

  Basic functionality of this library was origianlly based on the 
  demo-code provided by ITead studio (for the ITDB02 modules) and 
  NKC Electronics (for the RGB GLCD module/shield).

  This library supports a number of 8bit, 16bit and serial graphic 
  displays, and will work with both Arduino and chipKit boards. For a 
  full list of tested display modules and controllers, see the 
  document UTFT_Supported_display_modules_&_controllers.pdf.


  When using 8bit and 16bit display modules there are some 
  requirements you must adhere to. These requirements can be found 
  in the document UTFT_Requirements.pdf.
  There are no special requirements when using serial displays.

  You can always find the latest version of the library at 
  http://electronics.henningkarlsen.com/

  If you make any modifications or improvements to the code, I would 
  appreciate that you share the code with me so that I might include 
  it in the next release. I can be contacted through 
  http://electronics.henningkarlsen.com/contact.php.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the CC BY-NC-SA 3.0 license.
  Please see the included documents for further information.
*/

#include "UTFT.h"
#include <pins_arduino.h>
#include <Arduino.h>

// Include hardware-specific functions for the correct MCU
#if defined(__AVR__)
	#include <avr/pgmspace.h>
	#include "hardware/avr/HW_AVR.h"
	#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
		#include "hardware/avr/HW_ATmega1280.h" 
	#elif defined(__AVR_ATmega328P__)
		#include "hardware/avr/HW_ATmega328P.h"
	#elif defined(__AVR_ATmega32U4__)
		#include "hardware/avr/HW_ATmega32U4.h"
	#elif defined(__AVR_ATmega168__)
		#error "ATmega168 MCUs are not supported because they have too little flash memory!"
	#elif defined(__AVR_ATmega1284P__)
		#include "hardware/avr/HW_ATmega1284P.h"
	#else
		#error "Unsupported AVR MCU!"
	#endif
#elif defined(__PIC32MX__)
  #include "hardware/pic32/HW_PIC32.h"
  #if defined(__32MX320F128H__)
    #pragma message("Compiling for chipKIT UNO32 (__32MX320F128H__)")
	#include "hardware/pic32/HW_PIC32MX320F128H.h"
  #elif defined(__32MX340F512H__)
    #pragma message("Compiling for chipKIT uC32 (__32MX340F512H__)")
	#include "hardware/pic32/HW_PIC32MX340F512H.h"
  #elif defined(__32MX795F512L__)
    #pragma message("Compiling for chipKIT MAX32 (__32MX795F512L__)")
	#include "hardware/pic32/HW_PIC32MX795F512L.h"
  #else
    #error "Unsupported PIC32 MCU!"
  #endif  
#elif defined(__arm__)
	#include "hardware/arm/HW_ARM.h"
	#if defined(__SAM3X8E__)
		#pragma message("Compiling for Arduino Due (AT91SAM3X8E)...")
		#include "hardware/arm/HW_SAM3X8E.h"
	#else
		#error "Unsupported ARM MCU!"
	#endif
#endif
#include "memorysaver.h"

UTFT::UTFT()
{
}

UTFT::UTFT(int model, int RS, int WR,int CS, int RST, int STROBE, int CLEAR, int CLOCK, int DATA, int SER)
{ 
	this->CLEAR = CLEAR;
	this->DATA = DATA;
	this->STROBE = STROBE;
	this->CLOCK = CLOCK;
	switch (model)
	{
		case HX8347A:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			break;
		case ILI9327:
			disp_x_size=239;
			disp_y_size=399;
			display_transfer_mode=16;
			break;
		case SSD1289:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			break;
		case ILI9325C:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=8;
			break;
		case ILI9325D_8:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=8;
			break;
		case ILI9325D_16:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			break;
		case ILI9325D_16ALT:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			break;
		case HX8340B_8:
			disp_x_size=175;
			disp_y_size=219;
			display_transfer_mode=8;
			break;
		case HX8340B_S:
			disp_x_size=175;
			disp_y_size=219;
			display_transfer_mode=1;
			display_serial_mode=SERIAL_4PIN;
			break;
		case HX8352A:
			disp_x_size=239;
			disp_y_size=399;
			display_transfer_mode=16;
			break;
		case ST7735:
			disp_x_size=127;
			disp_y_size=159;
			display_transfer_mode=1;
			display_serial_mode=SERIAL_5PIN;
			break;
		case ST7735S:
			disp_x_size=127;
			disp_y_size=159;
			display_transfer_mode=1;
			display_serial_mode=SERIAL_5PIN;
			break;
		case PCF8833:
			disp_x_size=127;
			disp_y_size=127;
			display_transfer_mode=1;
			display_serial_mode=SERIAL_5PIN;
			break;
		case S1D19122:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			break;
		case SSD1963_480:
			disp_x_size=479;
			disp_y_size=271;
			display_transfer_mode=16;
			break;
		case SSD1963_800:
			disp_x_size=479;
			disp_y_size=799;
			display_transfer_mode=16;
			break;
		case SSD1963_800ALT:
			disp_x_size=479;
			disp_y_size=799;
			display_transfer_mode=16;
			break;
		case S6D1121_8:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=8;
			break;
		case S6D1121_16:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			break;
		case SSD1289LATCHED:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=LATCHED_16;
			break;
		case ILI9320_8:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=8;
			break;
		case ILI9320_16:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			break;
		case SSD1289_8:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=8;
			break;
		case ILI9481:
			disp_x_size=319;
			disp_y_size=479;
			display_transfer_mode=16;
			break;
		case S6D0164:
			disp_x_size=175;
			disp_y_size=219;
			display_transfer_mode=8;
			break;
		case ILI9341_S5P:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			//display_serial_mode=SERIAL_5PIN;
			break;
		case ILI9341_S4P:
			disp_x_size=239;
			disp_y_size=319;
			display_transfer_mode=16;
			//display_serial_mode=SERIAL_4PIN;
			break;
	}

		P_RS	= portOutputRegister(digitalPinToPort(RS));
		B_RS	= digitalPinToBitMask(RS);
		P_WR	= portOutputRegister(digitalPinToPort(WR));
		B_WR	= digitalPinToBitMask(WR);
		P_CS	= portOutputRegister(digitalPinToPort(CS));
		B_CS	= digitalPinToBitMask(CS);
		P_RST	= portOutputRegister(digitalPinToPort(RST));
		B_RST	= digitalPinToBitMask(RST);

  pinMode(DATA, OUTPUT);
  pinMode(CLOCK, OUTPUT);
  pinMode(CLEAR, OUTPUT);
  pinMode(STROBE, OUTPUT);
  //pinMode(4, OUTPUT);
  pinMode(RS, OUTPUT);
  pinMode(WR, OUTPUT);
  pinMode(CS, OUTPUT);
  pinMode(RST, OUTPUT);
  digitalWrite(STROBE,LOW);
  digitalWrite(CLEAR,HIGH);
  digitalWrite(RST,LOW);
  digitalWrite(RST,HIGH);
  
	display_model=model;

  this->prevused = 0;
  this->prevout = 0;

  this->disp_y_size = disp_y_size;
  this->disp_x_size = disp_x_size;
}
void UTFT::timer(int time)
{
    unsigned long previous;
    unsigned long final;
  
    previous = micros();
    final = previous + time;

    while (previous < final)
    {
        previous = micros();
    }
    
}

void UTFT::setpt(int value)
{
    digitalWrite(8,0);
    digitalWrite(8,1);
    //int k = 1;
    //int j = 1;
    int bitMask = (unsigned int)0x8000;
    int bitValue;
    for (int i=0; i<16; i++)
    {
      bitValue = bitMask & value;
      bitMask = (unsigned int)bitMask >> 1;
      if (bitValue != 0)
      {
        digitalWrite(6,1);
      }
      timer(1);
      bitValue = 0;
  //    digitalWrite(1,0);
    //  timer(1);
      
      digitalWrite(7,1);
      timer(1);

      
      digitalWrite(6,0);
      timer(1);

      digitalWrite(7,0);
      timer(1);
    }
      
      digitalWrite(9,0);
      timer(1);
      digitalWrite(9,1);
      timer(1);
      digitalWrite(9,0);
      timer(1);
     
     // digitalWrite(4,0);
     // delay(1000);
     // digitalWrite(4,1);
     // delay(1000);
     // digitalWrite(4,0);
     // delay(1000);
    
    //digitalWrite(2,0);
     // delay(100);
}
/*
void UTFT::setpt(int value,int number)
{
    //digitalWrite(2,0);
    digitalWrite(2,1);
    //int k = 1;
    //int j = 1;
    int bitMask = 0x80;
    int bitValue;
    int bitValue2;
    //int bitValue = bitMask & value;
    //int bitValue2;
    //if (bitValue != 0)
    //  bitValue2=1;
   // else
   //   bitValue2=0;
    for (int i=0; i<8; i++)
    {
      bitValue = bitMask & value;
      bitMask = bitMask >> 1;
      if (bitValue != 0)
          bitValue2=1;
      else
          bitValue2=0;
      timer(1);
      digitalWrite(0,bitValue2);
      timer(1);
      digitalWrite(1,1);
      digitalWrite(1,0);
      digitalWrite(1,1);
    }
    if (number == 0)
    {
      
      digitalWrite(3,0);
      digitalWrite(3,1);
      //digitalWrite(3,0);
    }
    else
    {
     
      digitalWrite(4,0);
      digitalWrite(4,1);
     // digitalWrite(4,0);
    }
    //digitalWrite(2,0);
}
*/
/*
EJW - Speed improvement
If value remains the same and subroutine was last called
Skip setpt output -- it's already there
*/
void UTFT::LCD_Write_COM(int VL)
{
   int out;
   timer(SMALL);
    //digitalWrite(13,0); 
    digitalWrite(5,0); 
    //digitalWrite(12,0);
    digitalWrite(4,0);
    //out = VL << 8;
    out = 0;	
    out |= VL;
    if (!(this->prevused == 1 && this->prevout == out))
    {
        setpt(out);      
    }
    timer(SMALL);
    //digitalWrite(13,1);
    //digitalWrite(12,1);
    digitalWrite(5,1);
    digitalWrite(4,1);
    timer(SMALL);
    this->prevout = out;
    this->prevused = 1; 

}
void UTFT::LCD_Write_DATA(int VL,int VH)
{
    int out;
    timer(SMALL);
    //digitalWrite(13,0);
    //digitalWrite(12,1);
    digitalWrite(5,0);
    digitalWrite(4,1);

    out = VH << 8;
    out += VL;
    if (!(this->prevused == 2 && this->prevout == out))
    {
        setpt(out);
    }
    timer(SMALL);
    //digitalWrite(13,1);
    //digitalWrite(12,1);  
    digitalWrite(5,1);
    digitalWrite(4,1);  
//    timer(SMALL);
    this->prevout = out;
    this->prevused = 2;
}
void UTFT::LCD_Write_DATA(int VL)
{
    int out;
    timer(SMALL);
    //digitalWrite(13,0); //WR 0
    //digitalWrite(12,1); //RS Always 0 in 8080 mode.
    digitalWrite(5,0); //WR 0
    digitalWrite(4,1); //RS Always 0 in 8080 mode.
    //out = VL << 8;
    out = 0;
    out |= VL;
    if (!(this->prevused == 2 && this->prevout == out))
    {
        setpt(out);
    }
    timer(SMALL);
    //digitalWrite(13,1);
    //digitalWrite(12,1);  
    digitalWrite(5,1);
    digitalWrite(4,1);  
//    timer(SMALL);
    this->prevout = out;
    this->prevused = 2;
}
void UTFT::LCD_Write_COM_DATA(char com1,int dat1)
{
     LCD_Write_COM(com1);
     LCD_Write_DATA(dat1>>8,dat1);
}
void UTFT::InitLCD4()
{
  digitalWrite(10,1);
  digitalWrite(10,0);
  digitalWrite(10,1);
  digitalWrite(11,0);

LCD_Write_COM(0x11);//sleep out 
	delay(20);
  LCD_Write_COM(0x01); //reset
  delay(15);
  LCD_Write_COM(0x28); //display off
  delay(5);
  LCD_Write_COM(0xCF); //power control b
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x83); //83 81 AA
  LCD_Write_DATA(0x30);
  LCD_Write_COM(0xED); //power on seq control
  LCD_Write_DATA(0x64); //64 67
  LCD_Write_DATA(0x03);
  LCD_Write_DATA(0x12);
  LCD_Write_DATA(0x81);
  LCD_Write_COM(0xE8); //timing control a
  LCD_Write_DATA(0x85);
  LCD_Write_DATA(0x01);
  LCD_Write_DATA(0x79); //79 78
  LCD_Write_COM(0xCB); //power control a
  LCD_Write_DATA(0x39);
  LCD_Write_DATA(0X2C);
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x34);
  LCD_Write_DATA(0x02);
  LCD_Write_COM(0xF7); //pump ratio control
  LCD_Write_DATA(0x20);
  LCD_Write_COM(0xEA); //timing control b
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x00);
  LCD_Write_COM(0xC0); //power control 2
  LCD_Write_DATA(0x26); //26 25
  LCD_Write_COM(0xC1); //power control 2
  LCD_Write_DATA(0x11);
  LCD_Write_COM(0xC5); //vcom control 1
  LCD_Write_DATA(0x35);
  LCD_Write_DATA(0x3E);
  LCD_Write_COM(0xC7); //vcom control 2
  LCD_Write_DATA(0xBE); //BE 94
  LCD_Write_COM(0xB1); //frame control
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x1B); //1B 70
  LCD_Write_COM(0xB6); //display control
  LCD_Write_DATA(0x0A);
  LCD_Write_DATA(0x82);
  LCD_Write_DATA(0x27);
  LCD_Write_DATA(0x00);
  LCD_Write_COM(0xB7); //emtry mode
  LCD_Write_DATA(0x07);
  LCD_Write_COM(0x3A); //pixel format
  LCD_Write_DATA(0x55); //16bit
  LCD_Write_COM(0x36); //mem access
  LCD_Write_DATA((1<<3)|(1<<6));
  //LCD_Write_DATA((1<<3)|(1<<7)); //rotate 180
  LCD_Write_COM(0x29); //display on
  delay(5);
  /*
	LCD_Write_COM(0x11);//sleep out 
	delay(20);
  LCD_Write_COM(0x01); //reset
  delay(15);
  LCD_Write_COM(0x28); //display off
  delay(5);
  LCD_Write_COM(0xCF); //power control b
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x83); //83 81 AA
  LCD_Write_DATA(0x30);
  LCD_Write_COM(0xED); //power on seq control
  LCD_Write_DATA(0x64); //64 67
  LCD_Write_DATA(0x03);
  LCD_Write_DATA(0x12);
  LCD_Write_DATA(0x81);
  LCD_Write_COM(0xE8); //timing control a
  LCD_Write_DATA(0x85);
  LCD_Write_DATA(0x01);
  LCD_Write_DATA(0x79); //79 78
  LCD_Write_COM(0xCB); //power control a
  LCD_Write_DATA(0x39);
  LCD_Write_DATA(0X2C);
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x34);
  LCD_Write_DATA(0x02);
  LCD_Write_COM(0xF7); //pump ratio control
  LCD_Write_DATA(0x20);
  LCD_Write_COM(0xEA); //timing control b
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x00);
  LCD_Write_COM(0xC0); //power control 2
  LCD_Write_DATA(0x26); //26 25
  LCD_Write_COM(0xC1); //power control 2
  LCD_Write_DATA(0x11);
  LCD_Write_COM(0xC5); //vcom control 1
  LCD_Write_DATA(0x35);
  LCD_Write_DATA(0x3E);
  LCD_Write_COM(0xC7); //vcom control 2
  LCD_Write_DATA(0xBE); //BE 94
  LCD_Write_COM(0xB1); //frame control
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x1B); //1B 70
  LCD_Write_COM(0xB6); //display control
  LCD_Write_DATA(0x0A);
  LCD_Write_DATA(0x82);
  LCD_Write_DATA(0x27);
  LCD_Write_DATA(0x00);
  LCD_Write_COM(0xB7); //emtry mode
  LCD_Write_DATA(0x07);
  LCD_Write_COM(0x3A); //pixel format
  LCD_Write_DATA(0x55); //16bit
  LCD_Write_COM(0x36); //mem access
  LCD_Write_DATA((1<<3)|(1<<6));
  //LCD_Write_DATA((1<<3)|(1<<7)); //rotate 180
  LCD_Write_COM(0x29); //display on
  delay(5);
  */
}
void UTFT::InitLCD3(int orientation)
{
  LCD_Write_COM(0xE2);    //PLL multiplier, set PLL clock to 120M
  LCD_Write_DATA(0x1E);     //N=0x36 for 6.5M, 0x23 for 10M crystal
  LCD_Write_DATA(0x02);
  LCD_Write_DATA(0x54);
  LCD_Write_COM(0xE0);    // PLL enable
  LCD_Write_DATA(0x01);
  delay(10);
  LCD_Write_COM(0xE0);
  LCD_Write_DATA(0x03);
  delay(10);
  LCD_Write_COM(0x01);    // software reset
  delay(100);
  LCD_Write_COM(0xE6);    //PLL setting for PCLK, depends on resolution
  LCD_Write_DATA(0x03);
  LCD_Write_DATA(0xFF);
  LCD_Write_DATA(0xFF);

  LCD_Write_COM(0xB0);    //LCD SPECIFICATION
  LCD_Write_DATA(0x24);
  LCD_Write_DATA(0x00);
  
  LCD_Write_DATA(0x03);   //Set HDP 799
  LCD_Write_DATA(0x1F);
  LCD_Write_DATA(0x01);   //Set VDP 479
  LCD_Write_DATA(0xDF);
  LCD_Write_DATA(0x00);

  LCD_Write_COM(0xB4);    //HSYNC
  LCD_Write_DATA(0x03);   //Set HT  928
  LCD_Write_DATA(0xA0);
  LCD_Write_DATA(0x00);   //Set HPS 46
  LCD_Write_DATA(0x2E);
  LCD_Write_DATA(0x30);   //Set HPW 48
  LCD_Write_DATA(0x00);   //Set LPS 15
  LCD_Write_DATA(0x0F);
  LCD_Write_DATA(0x00);

  LCD_Write_COM(0xB6);    //VSYNC
  LCD_Write_DATA(0x02);   //Set VT  525
  LCD_Write_DATA(0x0D);
  LCD_Write_DATA(0x00);   //Set VPS 16
  LCD_Write_DATA(0x10);
  LCD_Write_DATA(0x10);   //Set VPW 16
  LCD_Write_DATA(0x00);   //Set FPS 8
  LCD_Write_DATA(0x08);

  LCD_Write_COM(0xBA);
  LCD_Write_DATA(0x0F);   //GPIO[3:0] out 1

  LCD_Write_COM(0xB8);
  LCD_Write_DATA(0x07);     //GPIO3=input, GPIO[2:0]=output
  LCD_Write_DATA(0x01);   //GPIO0 normal

  LCD_Write_COM(0x36);    //rotation
  LCD_Write_DATA(0x22);

  LCD_Write_COM(0xF0);    //pixel data interface
  LCD_Write_DATA(0x03);


  delay(1);

  setXY(0, 0, 799, 479);
  LCD_Write_COM(0x29);    //display on

  LCD_Write_COM(0xBE);    //set PWM for B/L
  LCD_Write_DATA(0x06);
  LCD_Write_DATA(0xf0);
  LCD_Write_DATA(0x01);
  LCD_Write_DATA(0xf0);
  LCD_Write_DATA(0x00);
  LCD_Write_DATA(0x00);

  LCD_Write_COM(0xd0); 
  LCD_Write_DATA(0x0d); 

  LCD_Write_COM(0x2C); 

  delay(5);
  
}
void UTFT::InitLCD2()
{
//  digitalWrite(1,0);
  delay(5);
      LCD_Write_COM(0xE2);
          LCD_Write_DATA(0x23);            //PLL multiplier, set PLL clock to 120M 
        LCD_Write_DATA(0x2);       //N=0x36 for 6.5M, 0x23 for 10M crystal 
        LCD_Write_DATA(0x08); 
        LCD_Write_DATA(0x54); 
        LCD_Write_COM(0xE0);            // PLL enable 
        LCD_Write_DATA(0x01); 
        timer(10); 
        LCD_Write_COM(0xE0); 
        LCD_Write_DATA(0x03); 
        timer(10); 
        LCD_Write_COM(0x01);            // software reset 
        timer(100); 
        LCD_Write_COM(0xE6);            //PLL setting for PCLK, depends on resolution 
        LCD_Write_DATA(0x01); 
        LCD_Write_DATA(0x1F); 
        LCD_Write_DATA(0xFF); 
 
        LCD_Write_COM(0xB0);            //LCD SPECIFICATION 
        LCD_Write_DATA(0x20); 
        LCD_Write_DATA(0x00); 
        
        LCD_Write_DATA(0x01);           //Set HDP       479 
        LCD_Write_DATA(0xDF); 
        LCD_Write_DATA(0x01);           //Set VDP       271 
        LCD_Write_DATA(0x0F);
         
        //LCD_Write_DATA(0x03);           //Set HDP       799 
        //LCD_Write_DATA(0x1F); 
        //LCD_Write_DATA(0x01);           //Set VDP       479 
        //LCD_Write_DATA(0xDF);

        LCD_Write_DATA(0x00); 
 
        LCD_Write_COM(0xB4);            //HSYNC 
        LCD_Write_DATA(0x02);           //Set HT        531 
        LCD_Write_DATA(0x13); 
        LCD_Write_DATA(0x00);           //Set HPS       8 
        LCD_Write_DATA(0x08); 
        LCD_Write_DATA(0x2B);           //Set HPW       43 
        LCD_Write_DATA(0x00);           //Set LPS       2 
        LCD_Write_DATA(0x02); 
        LCD_Write_DATA(0x00); 
 
        LCD_Write_COM(0xB6);            //VSYNC 
        LCD_Write_DATA(0x01);           //Set VT        288 
        LCD_Write_DATA(0x20); 
        LCD_Write_DATA(0x00);           //Set VPS       4 
        LCD_Write_DATA(0x04); 
        LCD_Write_DATA(0x0c);           //Set VPW       12 
        LCD_Write_DATA(0x00);           //Set FPS       2 
        LCD_Write_DATA(0x02); 

        LCD_Write_COM(0xBA); 
        LCD_Write_DATA(0x0F);           //GPIO[3:0] out 1 
 
        LCD_Write_COM(0xB8); 
        LCD_Write_DATA(0x07);       //GPIO3=input, GPIO[2:0]=output 
        LCD_Write_DATA(0x01);           //GPIO0 normal 
 
        LCD_Write_COM(0x36);            //rotation 
        LCD_Write_DATA(0x22); 

        LCD_Write_COM(0xF0);            //pixel data interface 
        LCD_Write_DATA(0x03);
        timer(1);

        setXY(0, 0, 271, 479);
        //setXY(0,0,479,799);
        LCD_Write_COM(0x29);            //display on

        LCD_Write_COM(0xBE);            //set PWM for B/L
        LCD_Write_DATA(0x06);
        LCD_Write_DATA(0xf0);
        LCD_Write_DATA(0x01);
        LCD_Write_DATA(0xf0);
        LCD_Write_DATA(0x00);
        LCD_Write_DATA(0x00);

        LCD_Write_COM(0xd0); 
        LCD_Write_DATA(0x0d);   

        LCD_Write_COM(0x2C); 
        
//digitalWrite(11,1);
  
}
void UTFT::InitLCD(int orientation)
{
	orient=orientation;
	//_hw_special_init();

		//sbi(P_RST, B_RST);
		//cbi(P_RST, B_RST);
	//sbi(P_RST, B_RST);

	//cbi(P_CS, B_CS);

	UTFT::InitLCD2(); // Working 272 x 480
  //UTFT::InitLCD3();
	//sbi (P_CS, B_CS); 

	setClr(255, 0, 0);
	//setBackColor(0, 0, 255);
	cfont.font=0;
	_transparent = false;
}
void UTFT::setClr(unsigned int red,unsigned int green, unsigned int blue)
{
  LCD_Write_COM(0x2d);
  byte r1,r2,r3,g1,g2,g3,b1,b2,b3;
  r3 = red & 0x3f;
  r2 = (red >> 6) & 0x3f;
  r1 = (red >> 12) & 0x3f;
  LCD_Write_DATA(r3);
  LCD_Write_DATA(r2);
  LCD_Write_DATA(r1);
  g3 = green & 0x3f;
  g2 = (green >> 6) & 0x3f;
  g1 = (green >> 12) & 0x3f;
  LCD_Write_DATA(g3);
  LCD_Write_DATA(g2);
  LCD_Write_DATA(g1);
  b3 = blue & 0x3f;
  b2 = (blue >> 6) & 0x3f;
  b1 = (blue >> 12) & 0x3f;
  LCD_Write_DATA(b3);
  LCD_Write_DATA(b2);
  LCD_Write_DATA(b1);
 }
void UTFT::setXY(word x1, word y1, word x2, word y2)
{
	/*
	LCD_Write_COM_DATA(0x20,x1);
	LCD_Write_COM_DATA(0x21,y1);
	LCD_Write_COM_DATA(0x50,x1);
	LCD_Write_COM_DATA(0x52,y1);
	LCD_Write_COM_DATA(0x51,x2);
	LCD_Write_COM_DATA(0x53,y2);
	LCD_Write_COM(0x22); 
*/
/*
	LCD_Write_COM_DATA(0x44,(x2<<8)+x1);
	LCD_Write_COM_DATA(0x45,y1);
	LCD_Write_COM_DATA(0x46,y2);
	LCD_Write_COM_DATA(0x4e,x1);
	LCD_Write_COM_DATA(0x4f,y1);
	LCD_Write_COM(0x22); 
*/
/*

	LCD_Write_COM_DATA(0x02,x1>>8);
	LCD_Write_COM_DATA(0x03,x1);
	LCD_Write_COM_DATA(0x04,x2>>8);
	LCD_Write_COM_DATA(0x05,x2);
	LCD_Write_COM_DATA(0x06,y1>>8);
	LCD_Write_COM_DATA(0x07,y1);
	LCD_Write_COM_DATA(0x08,y2>>8);
	LCD_Write_COM_DATA(0x09,y2);
	LCD_Write_COM(0x22);      
*/
/*
	LCD_Write_COM_DATA(0x44,(x2<<8)+x1);
	LCD_Write_COM_DATA(0x45,y1);
	LCD_Write_COM_DATA(0x46,y2);
	LCD_Write_COM_DATA(0x4e,x1);
	LCD_Write_COM_DATA(0x4f,y1);
	LCD_Write_COM(0x22); 
*/
	/* WORKS FOR SSD1963
     LCD_Write_COM(0x2a);
     LCD_Write_DATA(x1>>8);
     LCD_Write_DATA(x1);
     LCD_Write_DATA(x2>>8);
     LCD_Write_DATA(x2);
     LCD_Write_COM(0x2b); 
     LCD_Write_DATA(y1>>8);
     LCD_Write_DATA(y1);
     LCD_Write_DATA(y2>>8);
     LCD_Write_DATA(y2);
     LCD_Write_COM(0x2c);
     */
     /*
      LCD_Write_COM_DATA(0x44,(x2<<8)+x1);
  LCD_Write_COM_DATA(0x45,y1);
  LCD_Write_COM_DATA(0x46,y2);
  LCD_Write_COM_DATA(0x4e,x1);
  LCD_Write_COM_DATA(0x4f,y1);
  LCD_Write_COM(0x22); 
     */
     
     	LCD_Write_COM(0x2A); //column
	LCD_Write_DATA(x1>>8);
	LCD_Write_DATA(x1);
	LCD_Write_DATA(x2>>8);
	LCD_Write_DATA(x2);
	LCD_Write_COM(0x2B); //page
	LCD_Write_DATA(y1>>8);
	LCD_Write_DATA(y1);
	LCD_Write_DATA(y2>>8);
	LCD_Write_DATA(y2);
	LCD_Write_COM(0x2C); //write
  LCD_Write_DATA(0x00);

}
void UTFT::clrXY()
{
  int disp_x_size,disp_y_size;
  disp_x_size = this->disp_x_size;
  disp_y_size = this->disp_y_size;
	if (orient==PORTRAIT)
		setXY(0,0,disp_x_size,disp_y_size);
	else
		setXY(0,0,disp_x_size,disp_y_size);
}

void UTFT::drawRect(int x1, int y1, int x2, int y2)
{

	if (x1>x2)
	{
		//swap(int, x1, x2);
	}
	if (y1>y2)
	{
		//swap(int, y1, y2);
	}

	drawHLine(x1, y1, x2-x1);
	drawHLine(x1, y2, x2-x1);
	drawVLine(x1, y1, y2-y1);
	drawVLine(x2, y1, y2-y1);
}

void UTFT::drawRoundRect(int x1, int y1, int x2, int y2)
{

	if (x1>x2)
	{
		//swap(int, x1, x2);
	}
	if (y1>y2)
	{
		//swap(int, y1, y2);
	}
	if ((x2-x1)>4 && (y2-y1)>4)
	{
		drawPixel(x1+1,y1+1);
		drawPixel(x2-1,y1+1);
		drawPixel(x1+1,y2-1);
		drawPixel(x2-1,y2-1);
		drawHLine(x1+2, y1, x2-x1-4);
		drawHLine(x1+2, y2, x2-x1-4);
		drawVLine(x1, y1+2, y2-y1-4);
		drawVLine(x2, y1+2, y2-y1-4);
	}
}

void UTFT::fillRect(int x1, int y1, int x2, int y2)
{

	if (x1>x2)
	{
		//swap(int, x1, x2);
	}
	if (y1>y2)
	{
		//swap(int, y1, y2);
	}
	if (display_transfer_mode==16)
	{
		//cbi(P_CS, B_CS);
		setXY(x1, y1, x2, y2);
		//sbi(P_RS, B_RS);
		_fast_fill_16(fch,fcl,((long(x2-x1)+1)*(long(y2-y1)+1)));
		//sbi(P_CS, B_CS);
	}
	else if ((display_transfer_mode==8) and (fch==fcl))
	{
		//cbi(P_CS, B_CS);
		setXY(x1, y1, x2, y2);
		//sbi(P_RS, B_RS);
		_fast_fill_8(fch,((long(x2-x1)+1)*(long(y2-y1)+1)));
		//sbi(P_CS, B_CS);
	}
	else
	{
		if (orient==PORTRAIT)
		{
			for (int i=0; i<((y2-y1)/2)+1; i++)
			{
				drawHLine(x1, y1+i, x2-x1);
				drawHLine(x1, y2-i, x2-x1);
			}
		}
		else
		{
			for (int i=0; i<((x2-x1)/2)+1; i++)
			{
				drawVLine(x1+i, y1, y2-y1);
				drawVLine(x2-i, y1, y2-y1);
			}
		}
	}
}

void UTFT::fillRoundRect(int x1, int y1, int x2, int y2)
{

	if ((x2-x1)>4 && (y2-y1)>4)
	{
		for (int i=0; i<((y2-y1)/2)+1; i++)
		{
			switch(i)
			{
			case 0:
				drawHLine(x1+2, y1+i, x2-x1-4);
				drawHLine(x1+2, y2-i, x2-x1-4);
				break;
			case 1:
				drawHLine(x1+1, y1+i, x2-x1-2);
				drawHLine(x1+1, y2-i, x2-x1-2);
				break;
			default:
				drawHLine(x1, y1+i, x2-x1);
				drawHLine(x1, y2-i, x2-x1);
			}
		}
	}
}

void UTFT::drawCircle(int x, int y, int radius)
{
	int f = 1 - radius;
	int ddF_x = 1;
	int ddF_y = -2 * radius;
	int x1 = 0;
	int y1 = radius;
  fch = 0xff;
  fcl = 0x0;
 
	//cbi(P_CS, B_CS);
	setXY(x, y + radius, x, y + radius);
	LCD_Write_DATA(fch,fcl);
	setXY(x, y - radius, x, y - radius);
	LCD_Write_DATA(fch,fcl);
	setXY(x + radius, y, x + radius, y);
	LCD_Write_DATA(fch,fcl);
	setXY(x - radius, y, x - radius, y);
	LCD_Write_DATA(fch,fcl);
 
	while(x1 < y1)
	{
		if(f >= 0) 
		{
			y1--;
			ddF_y += 2;
			f += ddF_y;
		}
		x1++;
		ddF_x += 2;
		f += ddF_x;    
		setXY(x + x1, y + y1, x + x1, y + y1);
		LCD_Write_DATA(fch,fcl);
		setXY(x - x1, y + y1, x - x1, y + y1);
		LCD_Write_DATA(fch,fcl);
		setXY(x + x1, y - y1, x + x1, y - y1);
		LCD_Write_DATA(fch,fcl);
		setXY(x - x1, y - y1, x - x1, y - y1);
		LCD_Write_DATA(fch,fcl);
		setXY(x + y1, y + x1, x + y1, y + x1);
		LCD_Write_DATA(fch,fcl);
		setXY(x - y1, y + x1, x - y1, y + x1);
		LCD_Write_DATA(fch,fcl);
		setXY(x + y1, y - x1, x + y1, y - x1);
		LCD_Write_DATA(fch,fcl);
		setXY(x - y1, y - x1, x - y1, y - x1);
		LCD_Write_DATA(fch,fcl);
	}
	//sbi(P_CS, B_CS);
	clrXY();
}

void UTFT::fillCircle(int x, int y, int radius)
{
	for(int y1=-radius; y1<=0; y1++) 
		for(int x1=-radius; x1<=0; x1++)
			if(x1*x1+y1*y1 <= radius*radius) 
			{
				drawHLine(x+x1, y+y1, 2*(-x1));
				drawHLine(x+x1, y-y1, 2*(-x1));
				break;
			}
}

void UTFT::_fast_fill_16(int VL,int VH,long pix)
{
    int out;
    timer(SMALL);
    //digitalWrite(13,0);
    //digitalWrite(12,1);
    digitalWrite(5,0);
    digitalWrite(4,1);
    out = VL << 8;
    out += VH;
    setpt(out);
    timer(SMALL);
    for (int i = 0; i<pix; i++)
    {
	//digitalWrite(13,1);
	//digitalWrite(13,0);
	digitalWrite(5,1);
	digitalWrite(5,0);
    }
    //digitalWrite(13,1);
    //digitalWrite(12,1);  
    digitalWrite(5,1);
    digitalWrite(4,1);  
}
void UTFT::clrScr()
{
  int disp_x_size;
  int disp_y_size;
	long i;
	
  disp_x_size = this->disp_y_size;
  disp_y_size = this->disp_x_size;
	//cbi(P_CS, B_CS);
	clrXY();
	if (display_transfer_mode!=1)
        {
		//sbi(P_RS, B_RS);
	}
	if (display_transfer_mode==16)
	{
		_fast_fill_16(0,0,((disp_x_size+1)*(disp_y_size+1)));
		//_fast_fill_16(0,0,((long(disp_x_size)+1)*(long(disp_y_size)+1)));
	}
	else if (display_transfer_mode==8)
	{
		_fast_fill_8(0,((disp_x_size+1)*(disp_y_size+1)));
	}
	else
	{
		for (i=0; i<((disp_x_size+1)*(disp_y_size+1)); i++)
		{
			if (display_transfer_mode!=1)
			{
				setpt(0);
				setpt(0);
			}
			else
			{
				setpt(0);
				setpt(0);
			}
		}
	}
	//sbi(P_CS, B_CS);
}

void UTFT::fillScr(int r, int g, int b)
{
	long color = ((r&248)<<8 | (g&252)<<3 | (b&248)>>3);
	fillScr(color);
}

void UTFT::fillScr(long color)
{
	long i;
	char ch, cl;
	
	ch=int(color>>8);
	cl=int(color & 0xFF);

	//cbi(P_CS, B_CS);
	clrXY();
	if (display_transfer_mode!=1)
        {
		//sbi(P_RS, B_RS);
        }
	if (display_transfer_mode==16)
	{
		_fast_fill_16(ch,cl,((disp_x_size+1)*(disp_y_size+1)));
        }
	else if ((display_transfer_mode==8) and (ch==cl))
        {
		_fast_fill_8(ch,((disp_x_size+1)*(disp_y_size+1)));
        }
	else
	{
		for (i=0; i<((disp_x_size+1)*(disp_y_size+1)); i++)
		{
			if (display_transfer_mode!=1)
			{
				int out;
				out = cl << 8;
				out += ch;
				setpt(out);
			}
			else
			{
				int out;
				out = cl << 8;
				out += ch;
				setpt(out);
			}
		}
	}
	//sbi(P_CS, B_CS);
}

void UTFT::setColor(byte r, byte g, byte b)
{
	fch=((r&248)|g>>5);
	fcl=((g&28)<<3|b>>3);
}

void UTFT::setColor(word color)
{
	fch=int(color>>8);
	fcl=int(color & 0xFF);
}
void UTFT::setTextColor(byte r, byte g, byte b)
{
	int tch,tcl;
	
	tch=((r&248)|g>>5);
	tcl=((g&28)<<3|b>>3);
	this->tch = tch;
	this->tcl = tcl;
}

void UTFT::setTextColor(word color)
{
	int tch,tcl;
	
	tch=int(color>>8);
	tcl=int(color & 0xFF);
	this->tch = tch;
	this->tcl = tcl;
}
long UTFT::getColor()
{
	return (fch<<8) | fcl;
}

void UTFT::setBackColor(int r, int g, int b)
{
	int bch,bcl;
	
	bch=((r&248)|g>>5);
	bcl=((g&28)<<3|b>>3);
	this->bch = bch;
	this->bcl = bcl;
}

void UTFT::setBackColor(unsigned long color)
{
	    int bch,bcl;
		
		bch=int(color>>8);
		bcl=int(color & 0xFF);
        this->bch = bch;
		this->bcl = bcl;
}

long UTFT::getBackColor()
{
	return (bch<<8) | bcl;
}

void UTFT::setPixel(long color)
{
	LCD_Write_DATA((color>>8),(color&0xFF));	// rrrrrggggggbbbbb
}
void UTFT::setPixel(int h,int l)
{
	LCD_Write_DATA(l,h);
}
void UTFT::drawPixel(int x, int y)
{
	//cbi(P_CS, B_CS);
	setXY(x, y, x+1, y+1);
	setPixel((fcl<<8)|fch);
	//sbi(P_CS, B_CS);
	//clrXY();
}

void UTFT::drawLine(int x1, int y1, int x2, int y2)
{
	int row,col;
	if (y1==y2)
		drawHLine(x1, y1, x2-x1);
	else if (x1==x2)
		drawVLine(x1, y1, y2-y1);
	else
	{
		unsigned int	dx = (x2 > x1 ? x2 - x1 : x1 - x2);
		short			xstep =  x2 > x1 ? 1 : -1;
		unsigned int	dy = (y2 > y1 ? y2 - y1 : y1 - y2);
		short			ystep =  y2 > y1 ? 1 : -1;
		int				col = x1, row = y1;

		//cbi(P_CS, B_CS);
		if (dx < dy)
		{
			int t = - (dy >> 1);
			while (true)
			{
				setXY(col,row,col+xstep,row+ystep);
				LCD_Write_DATA(fch,fcl);
				if (row == y2)
					return;
				row += ystep;
				t += dx;
				if (t >= 0)
				{
					col += xstep;
					t -= dy;
				}
			}
		}
		else
		{
			int t = - (dx >> 1);
			while (true)
			{
				setXY(col,row,col+xstep,row+ystep);
				LCD_Write_DATA(fch,fcl);
				if (col == x2)
					return;
				col += xstep;
				t += dy;
				if (t > 0)
				{
					row += ystep;
					t -= dx;
				}
			} 
		}
		//sbi(P_CS, B_CS);
	}
	clrXY();
}

void UTFT::drawHLine(int x, int y, int l)
{
	if (l<0)
	{
		l = -l;
		x -= l;
	}
	//cbi(P_CS, B_CS);
	setXY(x, y, x+l, y);
	if (display_transfer_mode == 16)
	{
		//sbi(P_RS, B_RS);
		_fast_fill_16(fch,fcl,l);
	}
	else if ((display_transfer_mode==8) and (fch==fcl))
	{
		//sbi(P_RS, B_RS);
		_fast_fill_8(fch,l);
	}
	else
	{
		for (int i=0; i<l+1; i++)
		{
			LCD_Write_DATA(fch, fcl);
		}
	}
	//sbi(P_CS, B_CS);
	clrXY();
}

void UTFT::drawVLine(int x, int y, int l)
{
	if (l<0)
	{
		l = -l;
		y -= l;
	}
	//cbi(P_CS, B_CS);
	setXY(x, y, x, y+l);
	if (display_transfer_mode == 16)
	{
		//sbi(P_RS, B_RS);
		_fast_fill_16(fch,fcl,l);
	}
	else if ((display_transfer_mode==8) and (fch==fcl))
	{
		//sbi(P_RS, B_RS);
		_fast_fill_8(fch,l);
	}
	else
	{
		for (int i=0; i<l+1; i++)
		{
			LCD_Write_DATA(fch, fcl);
		}
	}
	//sbi(P_CS, B_CS);
	clrXY();
}

void UTFT::lcdOff()
{
	//cbi(P_CS, B_CS);
	switch (display_model)
	{
	case PCF8833:
		LCD_Write_COM(0x28);
		break;
	}
	//sbi(P_CS, B_CS);
}

void UTFT::lcdOn()
{
	//cbi(P_CS, B_CS);
	switch (display_model)
	{
	case PCF8833:
		LCD_Write_COM(0x29);
		break;
	}
	//sbi(P_CS, B_CS);
}

void UTFT::setContrast(char c)
{
	//cbi(P_CS, B_CS);
	switch (display_model)
	{
	case PCF8833:
		if (c>64) c=64;
		LCD_Write_COM(0x25);
		LCD_Write_DATA(c);
		break;
	}
	//sbi(P_CS, B_CS);
}

int UTFT::getDisplayXSize()
{
	if (orient==PORTRAIT)
		return disp_x_size+1;
	else
		return disp_y_size+1;
}

int UTFT::getDisplayYSize()
{
	if (orient==PORTRAIT)
		return disp_y_size+1;
	else
		return disp_x_size+1;
}

void UTFT::setFont(uint8_t* font)
{
	cfont.font=font;
	cfont.x_size=fontbyte(0);
	cfont.y_size=fontbyte(1);
	cfont.offset=fontbyte(2);
	cfont.numchars=fontbyte(3);
}

uint8_t* UTFT::getFont()
{
	return cfont.font;
}

uint8_t UTFT::getFontXsize()
{
	return cfont.x_size;
}

uint8_t UTFT::getFontYsize()
{
	return cfont.y_size;
}
void UTFT::putChar(byte c,int row, int col)
{
	int xmax = 440;
	int ymax = 220;
	int y = (row * 11) + 26;
	//int x = (xmax - col * 11) + 20;
  int x = (col * 11) + 20;
    this->printChar(c,x,y,1);
}
void UTFT::putLarge(byte c,int row, int col)
{
  int xmax = 440;
  int ymax = 220;
  int y = (row * 16) + 36;
  //int x = (xmax - col * 11) + 20;
  int x = (col * 16) + 30;
    this->printChar(c,x,y,1);
}
void UTFT::printChar(byte c, int x, int y,int rotate)
{

	uint8_t theFont[]={         
0x08,0x0A,0x20,0x5F,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // Space
0x00,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x00,0x10, // !
0x00,0x00,0x24,0x24,0x24,0x00,0x00,0x00,0x00,0x00, // "
0x00,0x20,0x14,0x44,0x26,0x26,0x49,0x14,0x22,0x00, // #
0x00,0x28,0x3c,0x68,0x68,0x3c,0x2c,0x2c,0x78,0x00, // $
0x00,0x00,0x31,0x32,0x04,0x08,0x10,0x26,0x46,0x00, // %
0x00,0x1c,0x22,0x22,0x14,0x0c,0x30,0x7c,0x00,0x00, // &
0x00,0x04,0x04,0x04,0x04,0x00,0x00,0x00,0x00,0x00, // '
0x00,0x20,0x40,0x80,0x80,0x80,0x80,0x40,0x20,0x00, // (
0x00,0x04,0x02,0x01,0x01,0x01,0x01,0x02,0x04,0x00, // )
0x00,0x10,0x08,0x04,0x02,0x01,0x02,0x04,0x08,0x10, // >
0x00,0x00,0x10,0x10,0x10,0xFE,0x10,0x10,0x10,0x00, // +
0x00,0x00,0x00,0x00,0x00,0x00,0x08,0x10,0x20,0x40, // ,
0x00,0x00,0x00,0x00,0x00,0x7c,0x00,0x00,0x00,0x00, // -
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x18,0x18,0x00, // .
0x00,0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80, // /
0x00,0x18,0x24,0x42,0x42,0x42,0x24,0x18,0x00,0x00, // 0
0x00,0x10,0x30,0x10,0x10,0x10,0x10,0x10,0x38,0x00, // 1
0x00,0x18,0x24,0x04,0x04,0x08,0x10,0x20,0x20,0x7c, // 2
0x00,0x18,0x24,0x42,0x02,0x02,0x1c,0x04,0x02,0x3c, // 3
0x00,0x44,0x44,0x44,0x7c,0x04,0x04,0x04,0x04,0x04, // 4
0x00,0x7c,0x40,0x40,0x40,0x20,0x18,0x04,0x44,0x38, // 5
0x00,0x18,0x24,0x40,0x40,0x78,0x44,0x24,0x24,0x18, // 6
0x00,0x7e,0x04,0x04,0x08,0x08,0x10,0x10,0x20,0x20, // 7
0x00,0x18,0x24,0x44,0x48,0x38,0x24,0x44,0x48,0x30, // 8
0x00,0x18,0x24,0x44,0x44,0x3c,0x04,0x04,0x38,0x00, // 9
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // ; ??
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // : ??
0x00,0x02,0x04,0x18,0x20,0x40,0x20,0x10,0x0c,0x02, // <
0x00,0x00,0x7e,0x00,0x00,0x00,0x7e,0x00,0x00,0x00, // =
0x00,0x40,0x20,0x10,0x08,0x06,0x02,0x04,0x0c,0x70, // >
0x00,0x08,0x14,0x22,0x02,0x02,0x04,0x04,0x00,0x04, // ?
0x00,0x1c,0x22,0x40,0x58,0x5a,0x22,0x22,0x1c,0x00, // @
0x00,0x38,0x44,0x82,0x82,0x82,0xfe,0x82,0x82,0x82, // A
0x00,0x78,0x44,0x42,0x42,0x44,0x74,0x44,0x44,0x74, // B
0x00,0x3c,0x42,0x80,0x80,0x80,0x80,0x42,0x3c,0x00, // C
0x00,0xE0,0x9C,0x82,0x82,0x82,0x82,0x9C,0xF8,0x00, // D
0x00,0xFE,0x80,0x80,0x80,0xFC,0x80,0x80,0x80,0xFC, // E
0x00,0xFE,0x80,0x80,0x80,0xFC,0x80,0x80,0x80,0x80, // F
0x00,0x38,0x44,0x42,0x40,0x40,0x4E,0x42,0x3c,0x00, // G
0x00,0x82,0x82,0x82,0x82,0xFE,0x82,0x82,0x82,0x82, // H
0x00,0x7C,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x7c, // I
0x00,0x7E,0x08,0x08,0x08,0x08,0x08,0x08,0x90,0x60, // J
0x00,0x82,0x82,0x82,0x84,0x88,0x90,0xB0,0xC8,0x84, // K
0x00,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0xFC, // L
0x00,0xC6,0xAA,0xAA,0x92,0x82,0x82,0x82,0x82,0x82, // M
0x00,0xC4,0xA4,0xA4,0x94,0x94,0x94,0x44,0x8c,0x00, // N
0x00,0x18,0x24,0x42,0x42,0x42,0x42,0x44,0x7c,0x00, // O
0x00,0xF8,0x84,0x84,0x84,0xF8,0x80,0x80,0x80,0x80, // P
0x00,0x18,0x24,0x42,0x42,0x42,0x42,0x44,0x3E,0x02, // Q
0x00,0xF8,0x84,0x84,0x84,0xF8,0x84,0x84,0x82,0x81, // R
0x00,0x18,0x24,0x10,0x08,0x04,0x04,0x44,0x3C,0x00, // S
0x00,0xFE,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10, // T
0x00,0x82,0x82,0x82,0x82,0x82,0x82,0x82,0x7C,0x00, // U
0x00,0x81,0x81,0x81,0x42,0x22,0x22,0x14,0x1c,0x00, // V
0x00,0x81,0x81,0x81,0x41,0x41,0x49,0x2A,0x3C,0x00, // W
0x00,0x81,0x41,0x22,0x14,0x08,0x14,0x22,0x41,0x00, // X
0x00,0x82,0x44,0x28,0x10,0x10,0x10,0x10,0x10,0x10, // Y
0x00,0xFE,0x04,0x08,0x10,0x20,0x40,0x40,0xFE,0x00, // Z
0x00,0xF8,0x80,0x80,0x80,0x80,0x80,0x80,0x80,0xF8, // [
0x00,0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01,0x00, // BACKSLASH
0x00,0x1f,0x01,0x01,0x01,0x01,0x01,0x01,0x01,0x1f, // ]
0x00,0x00,0x08,0x24,0x42,0x00,0x00,0x00,0x00,0x00, // ^
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFE, // _
0x00,0x10,0x08,0x04,0x02,0x00,0x00,0x00,0x00,0x00, // `
0x00,0x00,0x00,0x0C,0x14,0x24,0x24,0x1B,0x00,0x00, // a
0x00,0x40,0x40,0x40,0x40,0x70,0x48,0x48,0x70,0x00, // b
0x00,0x00,0x00,0x00,0x38,0x44,0x40,0x40,0x38,0x00, // c
0x00,0x00,0x04,0x04,0x04,0x1c,0x24,0x24,0x1c,0x00, // d
0x00,0x00,0x00,0x1c,0x22,0x5E,0x40,0x20,0x1c,0x00, // e
0x00,0x18,0x14,0x10,0x10,0x38,0x10,0x10,0x10,0x00, // f
0x00,0x00,0x00,0x00,0x38,0x28,0x28,0x18,0x08,0x38, // g
0x00,0x40,0x40,0x40,0x40,0x58,0x64,0x44,0x44,0x00, // h
0x00,0x10,0x00,0x10,0x10,0x10,0x10,0x10,0x10,0x00, // i
0x00,0x10,0x00,0x10,0x10,0x10,0x10,0x10,0xE0,0x00, // j
0x00,0x40,0x40,0x40,0x44,0x68,0x50,0x48,0x44,0x00, // k
0x00,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x00, // l
0x00,0x00,0x00,0x00,0x36,0x49,0x49,0x49,0x49,0x00, // m
0x00,0x00,0x00,0x00,0x00,0x30,0x48,0x48,0x48,0x48, // n
0x00,0x00,0x00,0x00,0x18,0x24,0x24,0x24,0x18,0x00, // o
0x00,0x00,0x30,0x48,0x48,0x70,0x40,0x40,0x40,0x40, // p
0x00,0x00,0x18,0x24,0x24,0x1C,0x04,0x04,0x04,0x02, // q
0x00,0x00,0x00,0x00,0x2C,0x30,0x20,0x20,0x00,0x00, // r
0x00,0x00,0x00,0x00,0x3C,0x20,0x18,0x04,0x38,0x00, // s
0x00,0x00,0x00,0x00,0x10,0x38,0x10,0x10,0x10,0x00, // t
0x00,0x00,0x00,0x00,0x44,0x44,0x44,0x48,0x30,0x00, // u
0x00,0x00,0x00,0x00,0x44,0x28,0x28,0x10,0x00,0x00, // v
0x00,0x00,0x00,0x00,0x00,0x82,0x42,0x6A,0x3C,0x00, // w
0x00,0x00,0x00,0x40,0x24,0x14,0x14,0x24,0x00,0x00, // x
0x00,0x00,0x00,0x21,0x16,0x0C,0x04,0x08,0x10,0x20, // y
0x00,0x00,0x00,0x7e,0x02,0x04,0x08,0x10,0x20,0x7e, // z
0x00,0x28,0x06,0x01,0x01,0x02,0x01,0x01,0x06,0x08, // {
0x00,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10,0x10, // |
0x00,0x10,0x60,0x80,0x80,0x40,0x80,0x80,0x60,0x10, // }
0x00,0x00,0x00,0x20,0x52,0x0C,0x00,0x00,0x00,0x00  // ~
	};  
	int xbyte;
	//word temp;
	//temp=((c-cfont.offset)*((cfont.x_size/8)*cfont.y_size))+4;
	//uint8_t eee[] = {0x0,0x0,0xFF,0xFF,0x0,0x0,0xFF,0xFF,0x0,0x0,0xFF,0xFF};
	//uint8_t eeee[] = {0x00,0xFE,0x80,0x80,0x80,0xFC,0x80,0x80,0x80,0xFE,0x00,0x00};
    if (rotate == 0)
    {
         setXY(x,y,x+0x0a,y+0x08);
        for(int j=0x0;j<0x0a;j++) 
        {
	        xbyte = theFont[(((c-0x20-2)*0x0a)+4)+j];
			for (int i=8;i>=0;i--)
			{
				if ((xbyte & (1 << i)) == 0)   
				{
					setPixel(0x0);
				} 
				else
				{
					setPixel(0xffff);
				}   
			}
		}
	}
	else
	{
		setXY(x,y,x+0x08,y+0x0A);
		for(int j=0x0;j<0x08;j++) 
		{
			for (int i=0x0;i<=0x0A;i++)
			{
				xbyte = theFont[(((c-0x20-2)*0x0a)+4)+i];
				if ((xbyte & (1 << j)) == 0)   
				{
					setPixel(0x0);
				} 
				else
				{
					setPixel(0xffff);
				}
			}   
		}
	}	
}
void UTFT::printLarge(uint16_t *ptr, int x, int y,int rotate)
{

  uint16_t xbyte,*ptr2;
  //word temp;
  //temp=((c-cfont.offset)*((cfont.x_size/8)*cfont.y_size))+4;
  //uint8_t eee[] = {0x0,0x0,0xFF,0xFF,0x0,0x0,0xFF,0xFF,0x0,0x0,0xFF,0xFF};
  //uint8_t eeee[] = {0x00,0xFE,0x80,0x80,0x80,0xFC,0x80,0x80,0x80,0xFE,0x00,0x00};
  //  if (rotate == 0)
  //  {
  uint16_t i,j,k;
  int tcl,tch;
  int bcl,bch;
  
  bch = this->bch;
  bcl = this->bcl;
  
  tch = this->tch;
  tcl = this->tcl;

  if (rotate == 0 || rotate == 2)
  {
    setXY(x,y,x+0xf,y+0xf);
    if (rotate == 0)
    {
      ptr2 = ptr;
    }
    else
    {
      ptr2 = ptr+16;
    }
    for(int j=0x0;j<0x10;j++) 
    {
      //ptr2 = (uint16_t) ptr + j;
      //xbyte = theFont[offset];
      if (rotate == 0)
      {
        xbyte = *ptr2++;
      }
      else
      {
        xbyte = *--ptr2;
      }
      //xbyte = theChar;
      if (rotate == 0)
      {
        k = 0x8000;
      }
      else
      {
        k = 0x1;
      }
      for (int i=0x0;i<0x10;i++)
      {
        if ((xbyte & k) == 0)   
        {
		  setPixel(bch,bcl);
        } 
        else
        {
		  setPixel(tch,tcl);
        }
        if (rotate == 0)
        {
          k = k >> 1;
        }
        else
        {
          k = k << 1;
        }   
      }
    }
  }
  else
  {
    setXY(x,y,x+0xf,y+0xf);
    if (rotate == 1)
    {
      k = 0x1;
    }
    else
    {
      k = 0x8000;
    }
    for(int j=0x0;j<0x10;j++) 
    {
      //ptr2 = (uint16_t) ptr + j;
      //xbyte = theFont[offset];
      //xbyte = theChar;
      if (rotate == 1)
      {
        ptr2 = ptr;
      }
      else
      {
        ptr2 = ptr + 16;
      }
      for (int i=0x0;i<0x10;i++)
      {
        if (rotate == 1)
        {
          xbyte = *ptr2++;
        }
        else
        {
          xbyte = *--ptr2;
        }
        if ((xbyte & k) == 0)   
        {
		  setPixel(bch,bcl);
        } 
        else
        {
		  setPixel(tch,tcl);
        }
      }
    if (rotate == 1)
    {
      k = k << 1;
    }
    else
    {
      k = k >> 1;
    }   
    }    
  }
}
void UTFT::printHuge(uint16_t *ptr, int x, int y,int rotate)
{

  uint16_t xbyte,*ptr2;
  //word temp;
  //temp=((c-cfont.offset)*((cfont.x_size/8)*cfont.y_size))+4;
  //uint8_t eee[] = {0x0,0x0,0xFF,0xFF,0x0,0x0,0xFF,0xFF,0x0,0x0,0xFF,0xFF};
  //uint8_t eeee[] = {0x00,0xFE,0x80,0x80,0x80,0xFC,0x80,0x80,0x80,0xFE,0x00,0x00};
  //  if (rotate == 0)
  //  {
  uint16_t i,j,k,l;

  if (rotate == 0 || rotate == 2)
  {
    setXY(x,y,x+0x1f,y+0x1f);
    if (rotate == 0)
    {
      ptr2 = ptr;
    }
    else
    {
      ptr2 = ptr+16;
    }
    j = 0;
    while (j<0x20)
    {
      l = 0;
      //ptr2 = (uint16_t) ptr + j;
      //xbyte = theFont[offset];
      if (l == 1)
      {
      if (rotate == 0)
      {
        xbyte = *ptr2++;
      }
      else
      {
        xbyte = *--ptr2;
      }
        l = 0;
        j++;
      }
      else
      {
        l++;
        j++;
      }
      //xbyte = theChar;
      if (rotate == 0)
      {
        k = 0x8000;
      }
      else
      {
        k = 0x1;
      }
      for (int i=0x0;i<0x10;i++)
      {
        if ((xbyte & k) == 0)   
        {
          setPixel(0x0);
          setPixel(0x0);
        } 
        else
        {
          setPixel(0xffff);
          setPixel(0xffff);
        }
        if (rotate == 0)
        {
          k = k >> 1;
        }
        else
        {
          k = k << 1;
        }   
      }
    }
  }
  else
  {
    setXY(x,y,x+0x1f,y+0x1f);
    if (rotate == 1)
    {
      k = 0x1;
    }
    else
    {
      k = 0x8000;
    }
    j = 0;
    l = 0;
    while (j<0x20)
    {
      //ptr2 = (uint16_t) ptr + j;
      //xbyte = theFont[offset];
      //xbyte = theChar;
      if (rotate == 1)
      {
        ptr2 = ptr;
      }
      else
      {
        ptr2 = ptr + 16;
      }
      for (int i=0x0;i<0x10;i++)
      {
        if (rotate == 1)
        {
          xbyte = *ptr2++;
        }
        else
        {
          xbyte = *--ptr2;
        }
        if ((xbyte & k) == 0)   
        {
          setPixel(0x0);
          setPixel(0x0);
        } 
        else
        {
          setPixel(0xffff);
          setPixel(0xffff);
        }
      }
    if (l == 1)
    {
    if (rotate == 1)
    {
      k = k << 1;
    }
    else
    {
      k = k >> 1;
    }
    j++;
    l=0;
    } 
    else
    {
      j++;
      l++;
    }   
    }    
  }
}
/*
void UTFT::printChar(byte c, int x, int y)
{
	byte i,ch;
	word j;
	word temp; 

	//cbi(P_CS, B_CS);
  
	if (!_transparent)
	{
		if (orient==PORTRAIT)
		{
			setXY(x,y,x+cfont.x_size-1,y+cfont.y_size-1);
	  
			temp=((c-cfont.offset)*((cfont.x_size/8)*cfont.y_size))+4;
			for(j=0;j<((cfont.x_size/8)*cfont.y_size);j++)
			{
				ch=pgm_read_byte(&cfont.font[temp]);
				for(i=0;i<8;i++)
				{   
					if((ch&(1<<(7-i)))!=0)   
					{
						setPixel((fch<<8)|fcl);
					} 
					else
					{
						setPixel((bch<<8)|bcl);
					}   
				}
				temp++;
			}
		}
		else
		{
			temp=((c-cfont.offset)*((cfont.x_size/8)*cfont.y_size))+4;

			for(j=0;j<((cfont.x_size/8)*cfont.y_size);j+=(cfont.x_size/8))
			{
				setXY(x,y+(j/(cfont.x_size/8)),x+cfont.x_size-1,y+(j/(cfont.x_size/8)));
				for (int zz=(cfont.x_size/8)-1; zz>=0; zz--)
				{
					ch=pgm_read_byte(&cfont.font[temp+zz]);
					for(i=0;i<8;i++)
					{   
						if((ch&(1<<i))!=0)   
						{
							setPixel((fch<<8)|fcl);
						} 
						else
						{
							setPixel((bch<<8)|bcl);
						}   
					}
				}
				temp+=(cfont.x_size/8);
			}
		}
	}
	else
	{
		temp=((c-cfont.offset)*((cfont.x_size/8)*cfont.y_size))+4;
		for(j=0;j<cfont.y_size;j++) 
		{
			for (int zz=0; zz<(cfont.x_size/8); zz++)
			{
				ch=pgm_read_byte(&cfont.font[temp+zz]); 
				for(i=0;i<8;i++)
				{   
				
					if((ch&(1<<(7-i)))!=0)   
					{
						setXY(x+i+(zz*8),y+j,x+i+(zz*8)+1,y+j+1);
						setPixel((fch<<8)|fcl);
					} 
				}
			}
			temp+=(cfont.x_size/8);
		}
	}

	//sbi(P_CS, B_CS);
	//clrXY();
}
*/
void UTFT::rotateChar(byte c, int x, int y, int pos, int deg)
{
	byte i,j,ch;
	word temp; 
	int newx,newy;
	double radian;
	radian=deg*0.0175;  

	cbi(P_CS, B_CS);

	temp=((c-cfont.offset)*((cfont.x_size/8)*cfont.y_size))+4;
	for(j=0;j<cfont.y_size;j++) 
	{
		for (int zz=0; zz<(cfont.x_size/8); zz++)
		{
			ch=pgm_read_byte(&cfont.font[temp+zz]); 
			for(i=0;i<8;i++)
			{   
				newx=x+(((i+(zz*8)+(pos*cfont.x_size))*cos(radian))-((j)*sin(radian)));
				newy=y+(((j)*cos(radian))+((i+(zz*8)+(pos*cfont.x_size))*sin(radian)));

				setXY(newx,newy,newx+1,newy+1);
				
				if((ch&(1<<(7-i)))!=0)   
				{
					setPixel((fch<<8)|fcl);
				} 
				else  
				{
					if (!_transparent)
						setPixel((bch<<8)|bcl);
				}   
			}
		}
		temp+=(cfont.x_size/8);
	}
	sbi(P_CS, B_CS);
	clrXY();
}

void UTFT::print(char *st, int x, int y, int deg)
{
	int stl, i;

	stl = strlen(st);

	if (orient==PORTRAIT)
	{
	if (x==RIGHT)
		x=(disp_x_size+1)-(stl*cfont.x_size);
	if (x==CENTER)
		x=((disp_x_size+1)-(stl*cfont.x_size))/2;
	}
	else
	{
	if (x==RIGHT)
		x=(disp_y_size+1)-(stl*cfont.x_size);
	if (x==CENTER)
		x=((disp_y_size+1)-(stl*cfont.x_size))/2;
	}

	for (i=0; i<stl; i++)
		if (deg==0)
			printChar(*st++, x + (i*(cfont.x_size)), y, 0);
		else
			rotateChar(*st++, x, y, i, deg);
}

void UTFT::print(String st, int x, int y, int deg)
{
	char buf[st.length()+1];

	st.toCharArray(buf, st.length()+1);
	print(buf, x, y, deg);
}

void UTFT::printNumI(long num, int x, int y, int length, char filler)
{
	char buf[25];
	char st[27];
	boolean neg=false;
	int c=0, f=0;
  
	if (num==0)
	{
		if (length!=0)
		{
			for (c=0; c<(length-1); c++)
				st[c]=filler;
			st[c]=48;
			st[c+1]=0;
		}
		else
		{
			st[0]=48;
			st[1]=0;
		}
	}
	else
	{
		if (num<0)
		{
			neg=true;
			num=-num;
		}
	  
		while (num>0)
		{
			buf[c]=48+(num % 10);
			c++;
			num=(num-(num % 10))/10;
		}
		buf[c]=0;
	  
		if (neg)
		{
			st[0]=45;
		}
	  
		if (length>(c+neg))
		{
			for (int i=0; i<(length-c-neg); i++)
			{
				st[i+neg]=filler;
				f++;
			}
		}

		for (int i=0; i<c; i++)
		{
			st[i+neg+f]=buf[c-i-1];
		}
		st[c+neg+f]=0;

	}

	print(st,x,y);
}

void UTFT::printNumF(double num, byte dec, int x, int y, char divider, int length, char filler)
{
	char st[27];
	boolean neg=false;

	if (dec<1)
		dec=1;
	else if (dec>5)
		dec=5;

	if (num<0)
		neg = true;

	_convert_float(st, num, length, dec);

	if (divider != '.')
	{
		for (int i=0; i<sizeof(st); i++)
			if (st[i]=='.')
				st[i]=divider;
	}

	if (filler != ' ')
	{
		if (neg)
		{
			st[0]='-';
			for (int i=1; i<sizeof(st); i++)
				if ((st[i]==' ') || (st[i]=='-'))
					st[i]=filler;
		}
		else
		{
			for (int i=0; i<sizeof(st); i++)
				if (st[i]==' ')
					st[i]=filler;
		}
	}

	print(st,x,y);
}
void UTFT::spistar()
{
	pinMode(D_CS, OUTPUT);
	pinMode(A0, OUTPUT);
	pinMode(A1, OUTPUT);
	pinMode(A2, INPUT);
	digitalWrite(D_CS,LOW);
	digitalWrite(A0,HIGH);
	digitalWrite(A1,HIGH);
	//digitalWrite(D_IN,HIGH);
}
void UTFT::AD7843_Off()
{
	digitalWrite(D_CS,HIGH);
}
unsigned int UTFT::AD7843_Y()
{
	WriteCharTo7843(0x90);
//	digitalWrite(A2,HIGH);
//	digitalWrite(A2,LOW);
  digitalWrite(A0,HIGH);
  digitalWrite(A0,LOW);
	return this->ReadFromCharFrom7843();
}
unsigned int UTFT::AD7843_X()
{
	WriteCharTo7843(0xD0);
//	digitalWrite(A2,HIGH);
//	digitalWrite(A2,LOW);
  digitalWrite(A0,HIGH);
  digitalWrite(A0,LOW);
	return this->ReadFromCharFrom7843();
}
void UTFT::AD7843_On()
{
	digitalWrite(D_CS,LOW);
}
void UTFT::WriteCharTo7843(unsigned char num)
{
	unsigned char count=0;
	unsigned char temp;
	unsigned nop;
	temp = num;
//  digitalWrite(A2,LOW);
  digitalWrite(A0,LOW);
	for (count=0;count<8;count++)
	{
		if (temp&0x80)
//			digitalWrite(A1,HIGH);
      digitalWrite(A1,HIGH);
		else
//			digitalWrite(A1,LOW);
      digitalWrite(A1,LOW);
		temp = temp<<1;
		
//		digitalWrite(A2,LOW);
    digitalWrite(A0,LOW);
		nop++;
		nop++;
//		digitalWrite(A2,HIGH);
    digitalWrite(A0,HIGH);
		nop++;
		nop++;
	}
}
unsigned int UTFT::ReadFromCharFrom7843()
{
	unsigned nop;
	unsigned char count=0;
	unsigned int Num=0;
	for (count=0;count<12;count++)
	{
		Num<<=1;
//		digitalWrite(A2,HIGH);
    digitalWrite(A0,HIGH);
		nop++;
//		digitalWrite(A2,LOW);
    digitalWrite(A0,LOW);
		nop++;
//    if (digitalRead(A0))
    if (digitalRead(A2))
			Num++;
	}
	return(Num);
}
/*
void UTFT::drawBitmap(int x, int y, int sx, int sy, bitmapdatatype data, int scale)
{
	unsigned int col;
	int tx, ty, tc, tsx, tsy;

	if (scale==1)
	{
		if (orient==PORTRAIT)
		{
			cbi(P_CS, B_CS);
			setXY(x, y, x+sx-1, y+sy-1);
			for (tc=0; tc<(sx*sy); tc++)
			{
				col=pgm_read_word(&data[tc]);
				LCD_Write_DATA(col>>8,col & 0xff);
			}
			sbi(P_CS, B_CS);
		}
		else
		{
			cbi(P_CS, B_CS);
			for (ty=0; ty<sy; ty++)
			{
				setXY(x, y+ty, x+sx-1, y+ty);
				for (tx=sx-1; tx>=0; tx--)
				{
					col=pgm_read_word(&data[(ty*sx)+tx]);
					LCD_Write_DATA(col>>8,col & 0xff);
				}
			}
			sbi(P_CS, B_CS);
		}
	}
	else
	{
		if (orient==PORTRAIT)
		{
			cbi(P_CS, B_CS);
			for (ty=0; ty<sy; ty++)
			{
				setXY(x, y+(ty*scale), x+((sx*scale)-1), y+(ty*scale)+scale);
				for (tsy=0; tsy<scale; tsy++)
					for (tx=0; tx<sx; tx++)
					{
						col=pgm_read_word(&data[(ty*sx)+tx]);
						for (tsx=0; tsx<scale; tsx++)
							LCD_Write_DATA(col>>8,col & 0xff);
					}
			}
			sbi(P_CS, B_CS);
		}
		else
		{
			cbi(P_CS, B_CS);
			for (ty=0; ty<sy; ty++)
			{
				for (tsy=0; tsy<scale; tsy++)
				{
					setXY(x, y+(ty*scale)+tsy, x+((sx*scale)-1), y+(ty*scale)+tsy);
					for (tx=sx-1; tx>=0; tx--)
					{
						col=pgm_read_word(&data[(ty*sx)+tx]);
						for (tsx=0; tsx<scale; tsx++)
							LCD_Write_DATA(col>>8,col & 0xff);
					}
				}
			}
			sbi(P_CS, B_CS);
		}
	}
	clrXY();
}

void UTFT::drawBitmap(int x, int y, int sx, int sy, bitmapdatatype data, int deg, int rox, int roy)
{
	unsigned int col;
	int tx, ty, newx, newy;
	double radian;
	radian=deg*0.0175;  

	if (deg==0)
		drawBitmap(x, y, sx, sy, data);
	else
	{
		cbi(P_CS, B_CS);
		for (ty=0; ty<sy; ty++)
			for (tx=0; tx<sx; tx++)
			{
				col=pgm_read_word(&data[(ty*sx)+tx]);

				newx=x+rox+(((tx-rox)*cos(radian))-((ty-roy)*sin(radian)));
				newy=y+roy+(((ty-roy)*cos(radian))+((tx-rox)*sin(radian)));

				setXY(newx, newy, newx, newy);
				LCD_Write_DATA(col>>8,col & 0xff);
			}
		sbi(P_CS, B_CS);
	}
	clrXY();
}
*/
